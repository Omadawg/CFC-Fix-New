# CFC-Fix
This will fix teams prestiege and rivalries in College Football Coach
